<?
class Core_Html_Tag_Custom extends Core_Html_Tag_Abstract{

}
?>