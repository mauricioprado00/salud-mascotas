<?
class Core_Block_List_Button extends Core_Block_Template{
	
}
?>