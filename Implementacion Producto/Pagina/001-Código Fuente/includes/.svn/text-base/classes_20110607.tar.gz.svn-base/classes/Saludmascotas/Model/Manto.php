<?
class Saludmascotas_Model_Manto extends Core_Model_Abstract{
	public function init(){
		parent::init();
		$this->setId(null)
			->setNombre(null)
			->setRutaImagen(null)
			->setDescripcion(null)
		;
	}
	public function getDbTableName() 
	{
		return 'sm_manto';
	}
}
?>