<?
/**
 *@referencia Barrio(id_barrio) Saludmascotas_Model_Barrio(id)
 *@listar Barrio Saludmascotas_Model_Barrio
*/
class Saludmascotas_Model_Domicilio extends Core_Model_Abstract{
	public function init(){
		parent::init();
		$this->setId(null)
			->setCalleNumero(null)
			->setIdBarrio(null)
			->setLat(null)
			->setLng(null)
		;
	}
	public function getDbTableName() 
	{
		return 'sm_domicilio';
	}
}
?>