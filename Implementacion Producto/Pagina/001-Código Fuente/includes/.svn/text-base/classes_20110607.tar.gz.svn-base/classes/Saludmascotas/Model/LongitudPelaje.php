<?
class Saludmascotas_Model_LongitudPelaje extends Core_Model_Abstract{
	public function init(){
		parent::init();
		$this->setId(null)
			->setNombre(null)
		;
	}
	public function getDbTableName() 
	{
		return 'sm_longitud_pelaje';
	}
}
?>