<?
/**
 *@referencia Domicilio(id_domicilio) Saludmascotas_Model_Domicilio(id)
 *@referencia Dueno(id_dueno) Saludmascotas_Model_User(id)
 *@referencia EstadoMascota(id_estadomascota) Saludmascotas_Model_EstadoMascota(id)
 *@referencia LongitudPelaje(id_longitud_pelaje) Saludmascotas_Model_LongitudPelaje(id)
 *@referencia Manto(id_manto) Saludmascotas_Model_Manto(id)
 *@referencia Raza(id_raza) Saludmascotas_Model_Raza(id)
 *@listar Foto Saludmascotas_Model_FotoMascota
 *@listar Color Saludmascotas_Model_ColorMascota
*/
//*@listar Localidad Saludmascotas_Model_Localidad
class Saludmascotas_Model_Mascota extends Core_Model_Abstract{
	public function init(){
		parent::init();
		$this->setTableColumn(
			'id'
			,'activa'
			,'castrado'
			,'descripcion'
			,'destacada'
			,'entrenada'
			,'fecha_nacimiento'
			,'nombre'
			,'para_adoptar'
			,'para_cruza'
			,'para_venta'
			,'pedigree'
			,'quiere_destacar'
			,'sexo'
			,'tamano'
			,'id_domicilio'
			,'id_dueno'
			,'id_estadomascota'
			,'id_longitud_pelaje'
			,'id_manto'
			,'id_raza'
		);
		$this->addAutofilterFieldInput('fecha_nacimiento', array('Mysql_Helper','filterDateInput'));
		$this->addAutofilterFieldOutput('fecha_nacimiento', array('Mysql_Helper','filterDateOutput'));
	}
	public function getColoresAgregadosAsCollection(){
		$colores = $this->getListColor();
		if(!$colores)
			return null;
		$collection = new Core_Collection();
		foreach($colores as $color_mascota){
			$color = $color_mascota->getColor();
			$collection->addItem($color);
		}
		return $collection;
	}
	public function calcularEdad(){
		return 'calcularEdad';
	}
	public function getDbTableName() 
	{
		return 'sm_mascota';
	}
}
?>