<?
class Frontend_Block_Banners_Carrousel extends Core_Block_Template{
	public function _construct(){
		parent::_construct();
		$this->setTemplate('page/carrousel.phtml');
	}
}
?>