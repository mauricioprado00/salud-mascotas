<?
interface Core_IHtmlRenderer{
	public function getHtml();
}
?>