<?
/**
 *@referencia Mascota(id_mascota) Saludmascotas_Model_Mascota(id)
 *@referencia Color(id_color) Saludmascotas_Model_Color(id)
*/
class Saludmascotas_Model_ColorMascota extends Core_Model_Abstract{
	public function init(){
		parent::init();
		$this->setId(null)
			->setIdMascota(null)
			->setIdColor(null)
		;
	}
	public function getDbTableName() 
	{
		return 'sm_colormascota';
	}
}
?>