<?
class Saludmascotas_Model_EstadoMascota extends Core_Model_Abstract{
	public function init(){
		parent::init();
		$this->setId(null)
			->setNombre(null)
		;
	}
	public function getDbTableName() 
	{
		return 'sm_estadomascota';
	}
}
?>