<?
/**
 *@listar Raza Saludmascotas_Model_Raza
*/
class Saludmascotas_Model_Especie extends Core_Model_Abstract{
	public function init(){
		parent::init();
		$this->setId(null)
			->setNombre(null)
			->setDescripcion(null)
		;
	}
	public function getDbTableName() 
	{
		return 'sm_especie';
	}
}
?>