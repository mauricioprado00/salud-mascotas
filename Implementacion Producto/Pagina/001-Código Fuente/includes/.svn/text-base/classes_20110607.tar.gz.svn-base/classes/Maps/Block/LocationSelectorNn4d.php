<?php //es útf8 
class Maps_Block_LocationSelectorNn4d extends Core_Block_Template{
	public function __construct(){
		parent::__construct();
		$this->setTemplate('location_selector/nn4d.phtml');
	}
}
?>