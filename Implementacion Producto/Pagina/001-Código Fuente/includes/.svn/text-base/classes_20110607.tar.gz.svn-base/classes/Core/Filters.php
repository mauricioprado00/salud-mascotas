<?
class Core_Filter extends Core_Singleton{

	public function getInstance(){
		return(self::getInstanceOf(__CLASS__));
	}
}
?>