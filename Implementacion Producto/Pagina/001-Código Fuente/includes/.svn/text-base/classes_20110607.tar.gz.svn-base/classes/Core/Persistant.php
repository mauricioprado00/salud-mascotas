<?
class Core_Persistant extends Core_Object{
	
}
?>