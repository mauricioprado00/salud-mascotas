<?
class Admin_Objetivo_Block_ListResultadoEsperado extends Core_Block_Template{
	public function __construct(){
		$this
			->setTemplate('objetivo/listado_re.phtml')
		;
	}

}
?>