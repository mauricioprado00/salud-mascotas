<?php

class Frontend_Block_FileUpload extends Core_Block_Template{
	public function _construct(){
		parent::_construct();
		$this
			->setDropMessage('Arrastra tus archivos aqui')
			->setTemplate('page/file_upload.phtml')
		;
	}
}