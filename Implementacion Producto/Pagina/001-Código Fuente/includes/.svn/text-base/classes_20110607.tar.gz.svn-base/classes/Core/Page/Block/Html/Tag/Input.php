<?
class Core_Page_Block_Html_Tag_Input extends Core_Page_Block_Html_Tag{ 
	public function __construct(){
		parent::__construct();
		$this->setTagname('input');
	}
}

?>