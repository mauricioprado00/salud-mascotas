<?
abstract class Core_Block_aAbstract extends Core_Block_Abstract{

}
?>